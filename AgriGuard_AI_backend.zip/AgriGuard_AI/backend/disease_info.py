DISEASE_INFO = {

    "Tomato_Early_Blight": {
        "disease": "Tomato Early Blight",
        "severity": "Medium",
        "cause": "Fungal infection",
        "solution": "Remove infected leaves, improve air circulation and use a recommended fungicide."
    },

    "Tomato_Late_Blight": {
        "disease": "Tomato Late Blight",
        "severity": "High",
        "cause": "Phytophthora-like pathogen",
        "solution": "Remove affected plant parts, avoid excess moisture and use recommended treatment."
    },

    "Tomato_Healthy": {
        "disease": "Healthy Tomato Leaf",
        "severity": "Low",
        "cause": "No disease detected",
        "solution": "Continue regular watering, nutrition and monitoring."
    }
}


def get_disease_info(class_name):

    if class_name in DISEASE_INFO:
        return DISEASE_INFO[class_name]

    return {
        "disease": class_name,
        "severity": "Unknown",
        "cause": "Information not available",
        "solution": "Please consult an agricultural expert."
    }
