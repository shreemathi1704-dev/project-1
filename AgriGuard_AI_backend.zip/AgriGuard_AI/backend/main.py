import os
import io
import traceback

import numpy as np
import tensorflow as tf

from PIL import Image

from fastapi import (
    FastAPI,
    File,
    UploadFile
)

from fastapi.middleware.cors import CORSMiddleware

from database import (
    SessionLocal,
    Prediction
)

from disease_info import (
    get_disease_info
)


# ==================================================
# APP
# ==================================================

app = FastAPI(
    title="AgriGuard AI",
    version="1.0"
)


# ==================================================
# CORS
# ==================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"]
)


# ==================================================
# PATHS
# ==================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


MODEL_PATH = os.path.join(
    BASE_DIR,
    "model",
    "agriguard_model.keras"
)


CLASS_PATH = os.path.join(
    BASE_DIR,
    "model",
    "class_names.txt"
)


# ==================================================
# GLOBAL VARIABLES
# ==================================================

model = None
class_names = []


# ==================================================
# LOAD MODEL
# ==================================================

def load_ai_model():

    global model
    global class_names

    print()
    print("=" * 60)
    print("AGRIGUARD AI - MODEL LOADING")
    print("=" * 60)

    print("Project directory:")
    print(BASE_DIR)

    print()
    print("Model path:")
    print(MODEL_PATH)

    print()
    print("Class file:")
    print(CLASS_PATH)

    # ----------------------------------------------
    # Check model
    # ----------------------------------------------

    if not os.path.exists(MODEL_PATH):

        print()
        print("ERROR: MODEL FILE NOT FOUND")
        print(MODEL_PATH)

        model = None

        return False

    # ----------------------------------------------
    # Check classes
    # ----------------------------------------------

    if not os.path.exists(CLASS_PATH):

        print()
        print("ERROR: CLASS FILE NOT FOUND")
        print(CLASS_PATH)

        model = None

        return False

    try:

        print()
        print("Loading TensorFlow model...")

        model = tf.keras.models.load_model(
            MODEL_PATH
        )

        print("Model loaded successfully.")

        # ------------------------------------------
        # Load class names
        # ------------------------------------------

        with open(
            CLASS_PATH,
            "r",
            encoding="utf-8"
        ) as file:

            class_names = [
                line.strip()
                for line in file
                if line.strip()
            ]

        print()
        print("Classes:")
        print(class_names)

        print()
        print("Model input shape:")
        print(model.input_shape)

        print()
        print("Model output shape:")
        print(model.output_shape)

        print()
        print("=" * 60)
        print("AI MODEL READY")
        print("=" * 60)
        print()

        return True

    except Exception as error:

        print()
        print("MODEL LOADING ERROR")
        print(str(error))

        traceback.print_exc()

        model = None

        return False


# ==================================================
# LOAD MODEL
# ==================================================

load_ai_model()


# ==================================================
# HOME
# ==================================================

@app.get("/")
def home():

    return {
        "success": True,
        "message": "AgriGuard AI Backend is Running",
        "model_loaded": model is not None,
        "classes": class_names
    }


# ==================================================
# HEALTH
# ==================================================

@app.get("/health")
def health():

    return {
        "status": "online",
        "model_loaded": model is not None,
        "classes": class_names
    }


# ==================================================
# RELOAD MODEL
# ==================================================

@app.get("/reload-model")
def reload_model():

    success = load_ai_model()

    return {
        "success": success,
        "model_loaded": model is not None,
        "classes": class_names
    }


# ==================================================
# PREDICT
# ==================================================

@app.post("/predict")
async def predict(
    file: UploadFile = File(...)
):

    # =================================================
    # CHECK MODEL
    # =================================================

    if model is None:

        return {
            "success": False,
            "message": "AI model is not loaded. Check model/agriguard_model.keras."
        }

    # =================================================
    # CHECK CLASS NAMES
    # =================================================

    if len(class_names) == 0:

        return {
            "success": False,
            "message": "Class names are not loaded."
        }

    # =================================================
    # CHECK FILE
    # =================================================

    if file is None:

        return {
            "success": False,
            "message": "No file received."
        }

    if not file.filename:

        return {
            "success": False,
            "message": "No filename received."
        }

    # =================================================
    # READ IMAGE
    # =================================================

    try:

        image_bytes = await file.read()

        if len(image_bytes) == 0:

            return {
                "success": False,
                "message": "Uploaded image is empty."
            }

        print()
        print("Received image:")
        print(file.filename)

        print(
            "Image size:",
            len(image_bytes),
            "bytes"
        )

        # =============================================
        # OPEN IMAGE
        # =============================================

        image = Image.open(
            io.BytesIO(image_bytes)
        )

        print(
            "Original image size:",
            image.size
        )

        # =============================================
        # CONVERT RGB
        # =============================================

        image = image.convert("RGB")

        # =============================================
        # RESIZE
        # =============================================

        image = image.resize((224, 224))

        # =============================================
        # NUMPY ARRAY
        # =============================================

        image_array = np.asarray(
            image,
            dtype=np.float32
        )

        # =============================================
        # NORMALIZE
        # =============================================

        image_array = image_array / 255.0

        # =============================================
        # CHECK ARRAY
        # =============================================

        print(
            "Array shape:",
            image_array.shape
        )

        # =============================================
        # ADD BATCH
        # =============================================

        image_array = np.expand_dims(
            image_array,
            axis=0
        )

        print(
            "Input shape:",
            image_array.shape
        )

        # =============================================
        # PREDICT
        # =============================================

        predictions = model.predict(
            image_array,
            verbose=0
        )

        print(
            "Prediction:",
            predictions
        )

        # =============================================
        # GET RESULT
        # =============================================

        scores = predictions[0]

        predicted_index = int(
            np.argmax(scores)
        )

        confidence = float(
            scores[predicted_index]
        ) * 100

        # =============================================
        # SAFETY CHECK
        # =============================================

        if predicted_index >= len(class_names):

            return {
                "success": False,
                "message": "Model classes and class_names.txt do not match."
            }

        predicted_class = class_names[predicted_index]

        # =============================================
        # DISEASE INFO
        # =============================================

        info = get_disease_info(predicted_class)

        # =============================================
        # DATABASE
        # =============================================

        try:

            db = SessionLocal()

            record = Prediction(
                filename=file.filename,
                prediction=predicted_class,
                confidence=confidence
            )

            db.add(record)
            db.commit()
            db.close()

        except Exception as database_error:

            print(
                "Database error:",
                database_error
            )

        # =============================================
        # FINAL RESULT
        # =============================================

        result = {
            "success": True,
            "filename": file.filename,
            "prediction": predicted_class,
            "confidence": round(confidence, 2),
            "disease": info["disease"],
            "severity": info["severity"],
            "cause": info["cause"],
            "solution": info["solution"]
        }

        print()
        print("=" * 60)
        print("PREDICTION RESULT")
        print("=" * 60)
        print(result)
        print("=" * 60)
        print()

        return result

    # =================================================
    # ERROR
    # =================================================

    except Exception as error:

        print()
        print("PREDICTION ERROR")
        print(str(error))

        traceback.print_exc()

        return {
            "success": False,
            "message": "Image processing failed.",
            "error": str(error)
        }


# ==================================================
# HISTORY
# ==================================================

@app.get("/history")
def history():

    try:

        db = SessionLocal()

        records = (
            db.query(Prediction)
            .order_by(Prediction.id.desc())
            .limit(20)
            .all()
        )

        result = []

        for record in records:

            result.append({
                "id": record.id,
                "filename": record.filename,
                "prediction": record.prediction,
                "confidence": round(record.confidence, 2)
            })

        db.close()

        return result

    except Exception as error:

        return {
            "success": False,
            "message": str(error)
        }
