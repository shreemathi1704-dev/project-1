const API_URL = "http://127.0.0.1:8000";

const imageInput = document.getElementById("imageInput");
const fileName = document.getElementById("fileName");
const preview = document.getElementById("preview");
const previewSection = document.getElementById("previewSection");
const resultSection = document.getElementById("resultSection");
const loadingSection = document.getElementById("loadingSection");
const historyDiv = document.getElementById("history");
const detectButton = document.getElementById("detectButton");


// ==========================================
// IMAGE SELECT
// ==========================================

imageInput.addEventListener("change", function () {

    const file = imageInput.files[0];

    if (!file) {
        return;
    }

    fileName.textContent = file.name;
    preview.src = URL.createObjectURL(file);
    previewSection.style.display = "block";
    resultSection.style.display = "none";
});


// ==========================================
// PREDICT
// ==========================================

async function predictDisease() {

    const file = imageInput.files[0];

    if (!file) {
        alert("Please select an image.");
        return;
    }

    loadingSection.style.display = "block";
    resultSection.style.display = "none";
    detectButton.disabled = true;

    const formData = new FormData();
    formData.append("file", file);

    try {

        console.log("Sending image to:", API_URL);

        const response = await fetch(API_URL + "/predict", {
            method: "POST",
            body: formData
        });

        if (!response.ok) {
            throw new Error("HTTP Error: " + response.status);
        }

        const result = await response.json();

        console.log("Backend response:", result);

        if (!result.success) {
            throw new Error(result.message);
        }

        document.getElementById("disease").textContent = result.disease;
        document.getElementById("confidence").textContent = result.confidence + "%";
        document.getElementById("severity").textContent = result.severity;
        document.getElementById("cause").textContent = result.cause;
        document.getElementById("solution").textContent = result.solution;

        resultSection.style.display = "block";

        loadHistory();

    } catch (error) {

        console.error("ERROR:", error);
        alert("Backend connection failed.\n\n" + error.message);

    } finally {

        loadingSection.style.display = "none";
        detectButton.disabled = false;
    }
}


// ==========================================
// HISTORY
// ==========================================

async function loadHistory() {

    try {

        const response = await fetch(API_URL + "/history");
        const data = await response.json();

        historyDiv.innerHTML = "";

        if (!Array.isArray(data)) {
            historyDiv.innerHTML = "<p>Unable to load history.</p>";
            return;
        }

        if (data.length === 0) {
            historyDiv.innerHTML = "<p>No prediction history.</p>";
            return;
        }

        data.forEach(function (item) {

            const div = document.createElement("div");
            div.className = "history-item";

            div.innerHTML = `
                <strong>${item.prediction}</strong>
                <br>
                File: ${item.filename}
                <br>
                Confidence: ${item.confidence}%
            `;

            historyDiv.appendChild(div);
        });

    } catch (error) {
        console.error(error);
    }
}
